import { useState, useEffect, useCallback } from 'react';
import type { UserProgress, Avatar } from '@/types';

const STORAGE_KEY = 'gosmile_progress';
const DAILY_GOAL = 200;

export const AVATARS: Avatar[] = [
  {
    id: 'einstein',
    name: 'Einstein',
    image: '/avatars/einstein.jpg',
    unlockRequirement: { type: 'streak', value: 0 },
    description: 'Default avatar - The genius himself!',
  },
  {
    id: 'mona-lisa',
    name: 'Mona Lisa',
    image: '/avatars/mona-lisa.jpg',
    unlockRequirement: { type: 'streak', value: 3 },
    description: 'Unlock with 3-day streak',
  },
  {
    id: 'marilyn',
    name: 'Marilyn',
    image: '/avatars/marilyn.jpg',
    unlockRequirement: { type: 'total', value: 500 },
    description: 'Unlock with 500 total smiles',
  },
  {
    id: 'alpaca',
    name: 'Alpaca',
    image: '/avatars/alpaca.jpg',
    unlockRequirement: { type: 'streak', value: 7 },
    description: 'Unlock with 7-day streak',
  },
  {
    id: 'capybara',
    name: 'Capybara',
    image: '/avatars/capybara.jpg',
    unlockRequirement: { type: 'total', value: 1000 },
    description: 'Unlock with 1000 total smiles',
  },
  {
    id: 'giraffe',
    name: 'Giraffe',
    image: '/avatars/giraffe.jpg',
    unlockRequirement: { type: 'streak', value: 14 },
    description: 'Unlock with 14-day streak',
  },
  {
    id: 'quokka',
    name: 'Quokka',
    image: '/avatars/quokka.jpg',
    unlockRequirement: { type: 'total', value: 2000 },
    description: 'Unlock with 2000 total smiles',
  },
  {
    id: 'fox',
    name: 'Fox',
    image: '/avatars/fox.jpg',
    unlockRequirement: { type: 'streak', value: 30 },
    description: 'Unlock with 30-day streak',
  },
  {
    id: 'sloth',
    name: 'Sloth',
    image: '/avatars/sloth.jpg',
    unlockRequirement: { type: 'total', value: 5000 },
    description: 'Unlock with 5000 total smiles',
  },
];

const defaultProgress: UserProgress = {
  dailyGoal: DAILY_GOAL,
  dailyDone: 0,
  streak: 0,
  totalSmiles: 0,
  lastCompletedDate: null,
  selectedAvatar: 'einstein',
  unlockedAvatars: ['einstein'],
};

export function useProgress() {
  const [progress, setProgress] = useState<UserProgress>(defaultProgress);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load progress from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setProgress(prev => ({ ...prev, ...parsed }));
      } catch (e) {
        console.error('Error parsing progress:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Save progress to localStorage whenever it changes
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    }
  }, [progress, isLoaded]);

  // Check for daily reset
  useEffect(() => {
    if (!isLoaded) return;

    const today = new Date().toDateString();
    const lastDate = progress.lastCompletedDate;

    if (lastDate) {
      const lastDateObj = new Date(lastDate);
      const todayObj = new Date();
      const diffDays = Math.floor((todayObj.getTime() - lastDateObj.getTime()) / (1000 * 60 * 60 * 24));

      // If it's a new day
      if (today !== lastDate) {
        // Check if goal was completed yesterday
        const wasCompletedYesterday = progress.dailyDone >= progress.dailyGoal;
        
        // Reset daily progress
        setProgress(prev => ({
          ...prev,
          dailyDone: 0,
          // Increment streak if goal was met yesterday, otherwise reset
          streak: wasCompletedYesterday && diffDays === 1 ? prev.streak + 1 : wasCompletedYesterday ? prev.streak : 0,
        }));
      }
    }
  }, [isLoaded, progress.lastCompletedDate, progress.dailyDone, progress.dailyGoal]);

  // Add smiles to daily count
  const addSmile = useCallback(() => {
    setProgress(prev => {
      const newDailyDone = prev.dailyDone + 1;
      const newTotalSmiles = prev.totalSmiles + 1;
      
      // Check for newly unlocked avatars
      const newlyUnlocked = AVATARS.filter(avatar => {
        if (prev.unlockedAvatars.includes(avatar.id)) return false;
        
        const req = avatar.unlockRequirement;
        if (req.type === 'streak' && prev.streak >= req.value) return true;
        if (req.type === 'total' && newTotalSmiles >= req.value) return true;
        if (req.type === 'daily' && newDailyDone >= req.value) return true;
        
        return false;
      }).map(a => a.id);

      const updatedUnlocked = [...prev.unlockedAvatars, ...newlyUnlocked];

      // Check if daily goal is completed
      const isGoalCompleted = newDailyDone >= prev.dailyGoal;
      const today = new Date().toDateString();

      return {
        ...prev,
        dailyDone: newDailyDone,
        totalSmiles: newTotalSmiles,
        unlockedAvatars: updatedUnlocked,
        lastCompletedDate: isGoalCompleted ? today : prev.lastCompletedDate,
      };
    });
  }, []);

  // Add multiple smiles (for camera session)
  const addSmiles = useCallback((count: number) => {
    setProgress(prev => {
      const newDailyDone = prev.dailyDone + count;
      const newTotalSmiles = prev.totalSmiles + count;
      
      // Check for newly unlocked avatars
      const newlyUnlocked = AVATARS.filter(avatar => {
        if (prev.unlockedAvatars.includes(avatar.id)) return false;
        
        const req = avatar.unlockRequirement;
        if (req.type === 'streak' && prev.streak >= req.value) return true;
        if (req.type === 'total' && newTotalSmiles >= req.value) return true;
        if (req.type === 'daily' && newDailyDone >= req.value) return true;
        
        return false;
      }).map(a => a.id);

      const updatedUnlocked = [...prev.unlockedAvatars, ...newlyUnlocked];

      // Check if daily goal is completed
      const isGoalCompleted = newDailyDone >= prev.dailyGoal;
      const today = new Date().toDateString();

      return {
        ...prev,
        dailyDone: newDailyDone,
        totalSmiles: newTotalSmiles,
        unlockedAvatars: updatedUnlocked,
        lastCompletedDate: isGoalCompleted ? today : prev.lastCompletedDate,
      };
    });
  }, []);

  // Select avatar
  const selectAvatar = useCallback((avatarId: string) => {
    if (progress.unlockedAvatars.includes(avatarId)) {
      setProgress(prev => ({ ...prev, selectedAvatar: avatarId }));
    }
  }, [progress.unlockedAvatars]);

  // Check if avatar is unlocked
  const isAvatarUnlocked = useCallback((avatar: Avatar): boolean => {
    return progress.unlockedAvatars.includes(avatar.id);
  }, [progress.unlockedAvatars]);

  // Get unlock progress for an avatar
  const getUnlockProgress = useCallback((avatar: Avatar): { current: number; required: number; percentage: number } => {
    const req = avatar.unlockRequirement;
    let current = 0;

    switch (req.type) {
      case 'streak':
        current = progress.streak;
        break;
      case 'total':
        current = progress.totalSmiles;
        break;
      case 'daily':
        current = progress.dailyDone;
        break;
    }

    return {
      current,
      required: req.value,
      percentage: Math.min((current / req.value) * 100, 100),
    };
  }, [progress.streak, progress.totalSmiles, progress.dailyDone]);

  // Calculate daily progress percentage
  const dailyProgressPercentage = Math.min((progress.dailyDone / progress.dailyGoal) * 100, 100);

  // Check if daily goal is completed
  const isDailyGoalCompleted = progress.dailyDone >= progress.dailyGoal;

  return {
    progress,
    isLoaded,
    addSmile,
    addSmiles,
    selectAvatar,
    isAvatarUnlocked,
    getUnlockProgress,
    dailyProgressPercentage,
    isDailyGoalCompleted,
    avatars: AVATARS,
  };
}
