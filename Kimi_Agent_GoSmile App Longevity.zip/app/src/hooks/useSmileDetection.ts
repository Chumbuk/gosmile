import { useState, useRef, useCallback, useEffect } from 'react';
import type { SmileDetectionState } from '@/types';

// MediaPipe FaceMesh landmark indices for mouth corners
const MOUTH_LEFT = 61;
const MOUTH_RIGHT = 291;
const MOUTH_UPPER = 0;
const MOUTH_LOWER = 17;
const FACE_WIDTH_LEFT = 234;
const FACE_WIDTH_RIGHT = 454;

// Declare global MediaPipe types
declare global {
  interface Window {
    FaceMesh: any;
    Camera: any;
    drawConnectors: any;
    FACEMESH_TESSELATION: any;
    FACEMESH_LIPS: any;
  }
}

export function useSmileDetection(
  videoRef: React.RefObject<HTMLVideoElement | null>,
  canvasRef: React.RefObject<HTMLCanvasElement | null>,
  onSmileDetected: () => void
) {
  const [state, setState] = useState<SmileDetectionState>({
    isDetecting: false,
    smileCount: 0,
    isSmiling: false,
    confidence: 0,
  });

  const faceMeshRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const lastSmileTimeRef = useRef<number>(0);
  const smileCooldownRef = useRef<number>(1500); // 1.5 seconds between smiles
  const isSmilingRef = useRef<boolean>(false);

  // Calculate smile intensity based on mouth landmarks
  const calculateSmileIntensity = useCallback((landmarks: any[]): number => {
    if (!landmarks || landmarks.length === 0) return 0;

    const mouthLeft = landmarks[MOUTH_LEFT];
    const mouthRight = landmarks[MOUTH_RIGHT];
    const mouthUpper = landmarks[MOUTH_UPPER];
    const mouthLower = landmarks[MOUTH_LOWER];
    const faceLeft = landmarks[FACE_WIDTH_LEFT];
    const faceRight = landmarks[FACE_WIDTH_RIGHT];

    if (!mouthLeft || !mouthRight || !mouthUpper || !mouthLower || !faceLeft || !faceRight) {
      return 0;
    }

    // Calculate mouth width
    const mouthWidth = Math.sqrt(
      Math.pow(mouthRight.x - mouthLeft.x, 2) +
      Math.pow(mouthRight.y - mouthLeft.y, 2)
    );

    // Calculate face width for normalization
    const faceWidth = Math.sqrt(
      Math.pow(faceRight.x - faceLeft.x, 2) +
      Math.pow(faceRight.y - faceLeft.y, 2)
    );

    // Calculate mouth height
    const mouthHeight = Math.sqrt(
      Math.pow(mouthLower.x - mouthUpper.x, 2) +
      Math.pow(mouthLower.y - mouthUpper.y, 2)
    );

    // Calculate mouth curvature (smile indicator)
    // A smile has wider mouth relative to height and curved upward corners
    const mouthAspectRatio = mouthWidth / (mouthHeight + 0.001);
    const normalizedWidth = mouthWidth / (faceWidth + 0.001);

    // Combined smile score
    // Higher aspect ratio (wide mouth) and reasonable width indicate smile
    const smileScore = normalizedWidth * mouthAspectRatio * 10;

    return Math.min(Math.max(smileScore, 0), 1);
  }, []);

  // Process face detection results
  const onResults = useCallback((results: any) => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    
    if (!canvas || !video) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw video frame
    ctx.drawImage(results.image, 0, 0, canvas.width, canvas.height);

    if (results.multiFaceLandmarks && results.multiFaceLandmarks.length > 0) {
      const landmarks = results.multiFaceLandmarks[0];

      // Draw face mesh
      if (window.drawConnectors) {
        window.drawConnectors(ctx, landmarks, window.FACEMESH_TESSELATION, {
          color: 'rgba(243, 186, 0, 0.3)',
          lineWidth: 1,
        });
        window.drawConnectors(ctx, landmarks, window.FACEMESH_LIPS, {
          color: 'rgba(243, 186, 0, 0.8)',
          lineWidth: 2,
        });
      }

      // Calculate smile intensity
      const smileIntensity = calculateSmileIntensity(landmarks);
      const isSmilingNow = smileIntensity > 0.45; // Threshold for smile detection

      // Update state
      setState(prev => ({
        ...prev,
        isSmiling: isSmilingNow,
        confidence: smileIntensity,
      }));

      // Handle smile detection with cooldown
      const now = Date.now();
      if (isSmilingNow && !isSmilingRef.current) {
        // Smile started
        isSmilingRef.current = true;
        
        if (now - lastSmileTimeRef.current > smileCooldownRef.current) {
          lastSmileTimeRef.current = now;
          setState(prev => ({
            ...prev,
            smileCount: prev.smileCount + 1,
          }));
          onSmileDetected();
        }
      } else if (!isSmilingNow && isSmilingRef.current) {
        // Smile ended
        isSmilingRef.current = false;
      }

      // Draw smile indicator
      const centerX = canvas.width / 2;
      const centerY = canvas.height - 60;
      
      // Draw progress bar background
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.fillRect(centerX - 100, centerY, 200, 10);
      
      // Draw smile intensity bar
      const barColor = isSmilingNow 
        ? 'rgba(34, 197, 94, 1)' 
        : `rgba(243, 186, 0, ${0.3 + smileIntensity * 0.7})`;
      ctx.fillStyle = barColor;
      ctx.fillRect(centerX - 100, centerY, 200 * smileIntensity, 10);
      
      // Draw smile status text
      ctx.font = 'bold 18px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = isSmilingNow ? '#22c55e' : '#f3ba00';
      ctx.fillText(
        isSmilingNow ? '😊 SMILE DETECTED!' : 'Smile to count...',
        centerX,
        centerY - 15
      );
    }
  }, [calculateSmileIntensity, onSmileDetected, canvasRef, videoRef]);

  // Start smile detection
  const startDetection = useCallback(async () => {
    if (!videoRef.current) return;

    try {
      setState(prev => ({ ...prev, isDetecting: true, smileCount: 0 }));

      // Initialize FaceMesh
      const faceMesh = new window.FaceMesh({
        locateFile: (file: string) => {
          return `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`;
        },
      });

      faceMesh.setOptions({
        maxNumFaces: 1,
        refineLandmarks: true,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });

      faceMesh.onResults(onResults);
      faceMeshRef.current = faceMesh;

      // Initialize Camera
      const camera = new window.Camera(videoRef.current, {
        onFrame: async () => {
          await faceMesh.send({ image: videoRef.current });
        },
        width: 640,
        height: 480,
      });

      cameraRef.current = camera;
      await camera.start();

    } catch (error) {
      console.error('Error starting smile detection:', error);
      setState(prev => ({ ...prev, isDetecting: false }));
    }
  }, [onResults, videoRef]);

  // Stop smile detection
  const stopDetection = useCallback(() => {
    if (cameraRef.current) {
      cameraRef.current.stop();
      cameraRef.current = null;
    }
    if (faceMeshRef.current) {
      faceMeshRef.current.close();
      faceMeshRef.current = null;
    }
    setState(prev => ({ ...prev, isDetecting: false, isSmiling: false, confidence: 0 }));
    isSmilingRef.current = false;
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopDetection();
    };
  }, [stopDetection]);

  return {
    ...state,
    startDetection,
    stopDetection,
  };
}
