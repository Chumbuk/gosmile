import { Home, HelpCircle, Trophy, Users } from 'lucide-react';
import type { Screen } from '@/types';

interface BottomNavProps {
  activeScreen: Screen;
  onNavigate: (screen: Screen) => void;
}

export function BottomNav({ activeScreen, onNavigate }: BottomNavProps) {
  const navItems: { screen: Screen; icon: typeof Home; label: string }[] = [
    { screen: 'dashboard', icon: Home, label: 'Home' },
    { screen: 'faq', icon: HelpCircle, label: 'FAQ' },
    { screen: 'leaderboard', icon: Trophy, label: 'Leaderboard' },
    { screen: 'avatars', icon: Users, label: 'Avatars' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gosmile-bg/90 backdrop-blur-xl border-t border-white/10 safe-area-bottom">
      <div className="flex items-center justify-around px-4 py-3">
        {navItems.map(({ screen, icon: Icon, label }) => {
          const isActive = activeScreen === screen;
          
          return (
            <button
              key={screen}
              onClick={() => onNavigate(screen)}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'text-gosmile-yellow'
                  : 'text-white/50 hover:text-white/70'
              }`}
            >
              <Icon
                className={`w-6 h-6 transition-transform duration-200 ${
                  isActive ? 'scale-110' : ''
                }`}
              />
              <span className="text-xs font-medium">{label}</span>
              {isActive && (
                <div className="absolute bottom-1 w-1 h-1 rounded-full bg-gosmile-yellow" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
