import { useState, useCallback, useEffect } from 'react';
import { Dashboard } from '@/sections/Dashboard';
import { Camera } from '@/sections/Camera';
import { AvatarSelection } from '@/sections/AvatarSelection';
import { FAQ } from '@/sections/FAQ';
import { Leaderboard } from '@/sections/Leaderboard';
import { BottomNav } from '@/components/BottomNav';
import { useProgress } from '@/hooks/useProgress';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import type { Screen } from '@/types';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [showCamera, setShowCamera] = useState(false);
  
  const {
    progress,
    isLoaded,
    addSmiles,
    selectAvatar,
    isAvatarUnlocked,
    getUnlockProgress,
    dailyProgressPercentage,
    isDailyGoalCompleted,
    avatars,
  } = useProgress();

  // Get selected avatar details
  const selectedAvatar = avatars.find(a => a.id === progress.selectedAvatar) || avatars[0];

  // Handle starting camera
  const handleStartCamera = useCallback(() => {
    setShowCamera(true);
  }, []);

  // Handle finishing camera session
  const handleFinishCamera = useCallback((smileCount: number) => {
    setShowCamera(false);
    if (smileCount > 0) {
      addSmiles(smileCount);
      toast.success(`Great job! You smiled ${smileCount} times!`, {
        description: 'Your smiles have been added to your daily count.',
        duration: 3000,
      });
      
      // Check if daily goal was completed
      const newTotal = progress.dailyDone + smileCount;
      if (newTotal >= progress.dailyGoal && progress.dailyDone < progress.dailyGoal) {
        toast.success('🎉 Daily Goal Completed!', {
          description: `You've reached ${progress.dailyGoal} smiles today!`,
          duration: 5000,
        });
      }
    } else {
      toast.info('No smiles detected', {
        description: 'Try again with better lighting and a clear smile!',
        duration: 3000,
      });
    }
  }, [addSmiles, progress.dailyDone, progress.dailyGoal]);

  // Handle avatar selection
  const handleSelectAvatar = useCallback((avatarId: string) => {
    selectAvatar(avatarId);
    toast.success('Avatar updated!', {
      description: 'Your new avatar is now active.',
      duration: 2000,
    });
  }, [selectAvatar]);

  // Handle navigation
  const handleNavigate = useCallback((screen: Screen) => {
    setCurrentScreen(screen);
  }, []);

  // Handle back from sub-screens
  const handleBack = useCallback(() => {
    setCurrentScreen('dashboard');
  }, []);

  // Show welcome toast on first load
  useEffect(() => {
    if (isLoaded) {
      const hasSeenWelcome = sessionStorage.getItem('gosmile_welcome');
      if (!hasSeenWelcome) {
        toast.success('Welcome to GoSmile! 😊', {
          description: 'Start your journey to 200 smiles a day!',
          duration: 4000,
        });
        sessionStorage.setItem('gosmile_welcome', 'true');
      }
    }
  }, [isLoaded]);

  // Render current screen
  const renderScreen = () => {
    if (showCamera) {
      return (
        <Camera
          onFinish={handleFinishCamera}
          onBack={() => setShowCamera(false)}
        />
      );
    }

    switch (currentScreen) {
      case 'dashboard':
        return (
          <Dashboard
            progress={progress}
            selectedAvatar={selectedAvatar}
            dailyProgressPercentage={dailyProgressPercentage}
            isDailyGoalCompleted={isDailyGoalCompleted}
            onStartCamera={handleStartCamera}
            onOpenAvatars={() => setCurrentScreen('avatars')}
          />
        );
      
      case 'avatars':
        return (
          <AvatarSelection
            avatars={avatars}
            progress={progress}
            onSelect={handleSelectAvatar}
            onBack={handleBack}
            isAvatarUnlocked={isAvatarUnlocked}
            getUnlockProgress={getUnlockProgress}
          />
        );
      
      case 'faq':
        return <FAQ onBack={handleBack} />;
      
      case 'leaderboard':
        return <Leaderboard onBack={handleBack} userProgress={progress} />;
      
      default:
        return (
          <Dashboard
            progress={progress}
            selectedAvatar={selectedAvatar}
            dailyProgressPercentage={dailyProgressPercentage}
            isDailyGoalCompleted={isDailyGoalCompleted}
            onStartCamera={handleStartCamera}
            onOpenAvatars={() => setCurrentScreen('avatars')}
          />
        );
    }
  };

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-gosmile-bg flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-gosmile-yellow border-t-transparent rounded-full animate-spin" />
          <p className="text-white/60">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gosmile-bg">
      {renderScreen()}
      
      {/* Bottom Navigation - Hidden when camera is active */}
      {!showCamera && (
        <BottomNav
          activeScreen={currentScreen}
          onNavigate={handleNavigate}
        />
      )}
      
      {/* Toast notifications */}
      <Toaster 
        position="top-center"
        toastOptions={{
          style: {
            background: 'rgba(13, 17, 23, 0.95)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            color: '#fff',
          },
        }}
      />
    </div>
  );
}

export default App;
