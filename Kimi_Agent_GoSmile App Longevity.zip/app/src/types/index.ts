export interface UserProgress {
  dailyGoal: number;
  dailyDone: number;
  streak: number;
  totalSmiles: number;
  lastCompletedDate: string | null;
  selectedAvatar: string;
  unlockedAvatars: string[];
}

export interface Avatar {
  id: string;
  name: string;
  image: string;
  unlockRequirement: {
    type: 'streak' | 'total' | 'daily';
    value: number;
  };
  description: string;
}

export type Screen = 'dashboard' | 'camera' | 'avatars' | 'faq' | 'leaderboard';

export interface SmileDetectionState {
  isDetecting: boolean;
  smileCount: number;
  isSmiling: boolean;
  confidence: number;
}

export interface FaceLandmark {
  x: number;
  y: number;
  z: number;
}

export interface FaceMeshResults {
  multiFaceLandmarks: FaceLandmark[][];
}
