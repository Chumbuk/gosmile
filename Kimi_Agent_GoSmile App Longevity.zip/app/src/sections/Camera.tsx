import { useRef, useState, useCallback, useEffect } from 'react';
import { ArrowLeft, Camera as CameraIcon, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSmileDetection } from '@/hooks/useSmileDetection';

interface CameraScreenProps {
  onFinish: (smileCount: number) => void;
  onBack: () => void;
}

export function Camera({ onFinish, onBack }: CameraScreenProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [sessionSmiles, setSessionSmiles] = useState(0);
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSmileDetected = useCallback(() => {
    setSessionSmiles(prev => prev + 1);
  }, []);

  const { isDetecting, isSmiling, confidence, startDetection, stopDetection } = useSmileDetection(
    videoRef,
    canvasRef,
    handleSmileDetected
  );

  // Start camera when component mounts
  useEffect(() => {
    const initCamera = async () => {
      try {
        // Check for camera permission
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach(track => track.stop());
        
        setIsReady(true);
        await startDetection();
      } catch (err) {
        console.error('Camera error:', err);
        setError('Unable to access camera. Please allow camera permissions and try again.');
      }
    };

    initCamera();

    return () => {
      stopDetection();
    };
  }, [startDetection, stopDetection]);

  const handleFinish = useCallback(() => {
    stopDetection();
    onFinish(sessionSmiles);
  }, [stopDetection, onFinish, sessionSmiles]);

  const handleRetry = useCallback(() => {
    setError(null);
    setIsReady(false);
    setSessionSmiles(0);
    startDetection();
  }, [startDetection]);

  if (error) {
    return (
      <div className="flex flex-col min-h-screen items-center justify-center px-6">
        <div className="text-center space-y-6">
          <div className="w-20 h-20 rounded-full bg-red-500/20 flex items-center justify-center mx-auto">
            <CameraIcon className="w-10 h-10 text-red-500" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white mb-2">Camera Error</h2>
            <p className="text-white/60">{error}</p>
          </div>
          <div className="flex gap-3 justify-center">
            <Button
              onClick={onBack}
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button
              onClick={handleRetry}
              className="bg-gosmile-yellow text-black hover:bg-gosmile-yellow-light"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4">
        <button
          onClick={onBack}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <span className="text-lg font-bold text-white">Smile Tracker</span>
        <div className="w-9" /> {/* Spacer for alignment */}
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 py-4 gap-6">
        {/* Camera Container */}
        <div className="relative">
          {/* Circular Camera Frame */}
          <div
            className={`relative w-72 h-72 rounded-full overflow-hidden border-4 transition-all duration-300 ${
              isSmiling
                ? 'border-gosmile-green shadow-glow-green'
                : isDetecting
                ? 'border-gosmile-yellow shadow-glow-yellow'
                : 'border-white/20'
            }`}
          >
            {/* Video Element */}
            <video
              ref={videoRef}
              className="absolute inset-0 w-full h-full object-cover"
              playsInline
              muted
            />
            
            {/* Canvas Overlay */}
            <canvas
              ref={canvasRef}
              width={640}
              height={480}
              className="absolute inset-0 w-full h-full object-cover"
            />

            {/* Loading State */}
            {!isReady && (
              <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
                <div className="w-12 h-12 border-4 border-gosmile-yellow border-t-transparent rounded-full animate-spin" />
                <p className="text-white/60 mt-4 text-sm">Starting camera...</p>
              </div>
            )}
          </div>

          {/* Smile Counter Badge */}
          <div className="absolute -top-2 -right-2 w-16 h-16 rounded-full bg-gradient-to-br from-gosmile-yellow to-gosmile-yellow-dark flex flex-col items-center justify-center shadow-lg">
            <span className="text-2xl font-black text-black">{sessionSmiles}</span>
            <span className="text-[10px] text-black/70 font-semibold">SMILES</span>
          </div>

          {/* Detection Status Indicator */}
          {isDetecting && (
            <div 
              className={`absolute -bottom-2 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-sm font-semibold transition-all duration-200 ${
                isSmiling
                  ? 'bg-gosmile-green text-white'
                  : 'bg-white/10 text-white/80'
              }`}
            >
              {isSmiling ? '😊 Smile Detected!' : 'Detecting...'}
            </div>
          )}
        </div>

        {/* Instructions */}
        <div className="text-center space-y-2">
          <p className="text-white font-medium">
            {isSmiling ? 'Great smile! Keep it up!' : 'Look at the camera and smile!'}
          </p>
          <p className="text-white/50 text-sm">
            Position your face in the circle and smile naturally
          </p>
        </div>

        {/* Confidence Bar */}
        <div className="w-full max-w-xs">
          <div className="flex justify-between text-xs text-white/50 mb-1">
            <span>Smile Intensity</span>
            <span>{Math.round(confidence * 100)}%</span>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-200 ${
                isSmiling ? 'bg-gosmile-green' : 'bg-gosmile-yellow'
              }`}
              style={{ width: `${confidence * 100}%` }}
            />
          </div>
        </div>

        {/* Tips */}
        <div className="bg-white/5 rounded-2xl p-4 max-w-xs">
          <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
            <span className="text-gosmile-yellow">💡</span> Tips for best results:
          </h3>
          <ul className="text-white/60 text-sm space-y-1">
            <li>• Ensure good lighting on your face</li>
            <li>• Keep your face centered in the circle</li>
            <li>• Smile naturally with your mouth open</li>
            <li>• Hold each smile for 1-2 seconds</li>
          </ul>
        </div>

        {/* Finish Button */}
        <Button
          onClick={handleFinish}
          className="w-full max-w-xs bg-gosmile-yellow hover:bg-gosmile-yellow-light text-black font-bold py-6 rounded-2xl"
        >
          Finish Session
        </Button>

        <p className="text-white/40 text-xs">
          Your smiles will be added to your daily count
        </p>
      </main>
    </div>
  );
}
