import { ArrowLeft, Lock, Check, Flame, Smile, Trophy } from 'lucide-react';
import type { Avatar, UserProgress } from '@/types';

interface AvatarSelectionProps {
  avatars: Avatar[];
  progress: UserProgress;
  onSelect: (avatarId: string) => void;
  onBack: () => void;
  isAvatarUnlocked: (avatar: Avatar) => boolean;
  getUnlockProgress: (avatar: Avatar) => { current: number; required: number; percentage: number };
}

export function AvatarSelection({
  avatars,
  progress,
  onSelect,
  onBack,
  isAvatarUnlocked,
  getUnlockProgress,
}: AvatarSelectionProps) {
  const getRequirementIcon = (type: string) => {
    switch (type) {
      case 'streak':
        return <Flame className="w-4 h-4" />;
      case 'total':
        return <Smile className="w-4 h-4" />;
      case 'daily':
        return <Trophy className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getRequirementText = (avatar: Avatar) => {
    const req = avatar.unlockRequirement;
    switch (req.type) {
      case 'streak':
        return `${req.value} day streak`;
      case 'total':
        return `${req.value} total smiles`;
      case 'daily':
        return `${req.value} smiles in one day`;
      default:
        return '';
    }
  };

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4">
        <button
          onClick={onBack}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <span className="text-lg font-bold text-white">Choose Avatar</span>
        <div className="w-9" /> {/* Spacer for alignment */}
      </header>

      {/* Main Content */}
      <main className="flex-1 px-6 py-4">
        {/* Current Selection */}
        <div className="text-center mb-6">
          <p className="text-white/60 text-sm mb-2">Currently Selected</p>
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-gosmile-yellow/20 border border-gosmile-yellow/30">
            <img
              src={avatars.find(a => a.id === progress.selectedAvatar)?.image}
              alt="Current"
              className="w-8 h-8 rounded-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${progress.selectedAvatar}`;
              }}
            />
            <span className="text-gosmile-yellow font-semibold">
              {avatars.find(a => a.id === progress.selectedAvatar)?.name}
            </span>
            <Check className="w-4 h-4 text-gosmile-yellow" />
          </div>
        </div>

        {/* Avatar Grid */}
        <div className="grid grid-cols-3 gap-4">
          {avatars.map((avatar) => {
            const isUnlocked = isAvatarUnlocked(avatar);
            const isSelected = progress.selectedAvatar === avatar.id;
            const unlockProgress = getUnlockProgress(avatar);

            return (
              <button
                key={avatar.id}
                onClick={() => isUnlocked && onSelect(avatar.id)}
                disabled={!isUnlocked}
                className={`relative group flex flex-col items-center gap-2 p-3 rounded-2xl transition-all duration-200 ${
                  isUnlocked
                    ? isSelected
                      ? 'bg-gosmile-yellow/20 border-2 border-gosmile-yellow'
                      : 'bg-white/5 border-2 border-transparent hover:bg-white/10 hover:border-white/20'
                    : 'bg-white/5 border-2 border-transparent opacity-70'
                }`}
              >
                {/* Avatar Image */}
                <div className="relative w-20 h-20">
                  <img
                    src={avatar.image}
                    alt={avatar.name}
                    className={`w-full h-full rounded-full object-cover transition-all duration-200 ${
                      isUnlocked ? '' : 'grayscale'
                    }`}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${avatar.id}`;
                    }}
                  />

                  {/* Lock Overlay */}
                  {!isUnlocked && (
                    <div className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center">
                      <Lock className="w-6 h-6 text-white/70" />
                    </div>
                  )}

                  {/* Selected Indicator */}
                  {isSelected && (
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-gosmile-yellow flex items-center justify-center">
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}
                </div>

                {/* Avatar Name */}
                <span className={`text-sm font-medium ${isUnlocked ? 'text-white' : 'text-white/50'}`}>
                  {avatar.name}
                </span>

                {/* Unlock Status */}
                {!isUnlocked ? (
                  <div className="w-full space-y-1">
                    <div className="flex items-center justify-center gap-1 text-xs text-white/50">
                      {getRequirementIcon(avatar.unlockRequirement.type)}
                      <span>{getRequirementText(avatar)}</span>
                    </div>
                    {/* Progress Bar */}
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gosmile-yellow rounded-full transition-all duration-300"
                        style={{ width: `${unlockProgress.percentage}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-white/40 text-center">
                      {unlockProgress.current} / {unlockProgress.required}
                    </p>
                  </div>
                ) : (
                  <span className="text-xs text-gosmile-green flex items-center gap-1">
                    <Check className="w-3 h-3" /> Unlocked
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Info Card */}
        <div className="mt-6 p-4 rounded-2xl bg-gradient-to-br from-gosmile-yellow/10 to-orange-500/10 border border-gosmile-yellow/20">
          <h3 className="text-gosmile-yellow font-semibold mb-2 flex items-center gap-2">
            <Trophy className="w-5 h-5" />
            How to Unlock Avatars
          </h3>
          <ul className="text-white/60 text-sm space-y-2">
            <li className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-500" />
              Maintain daily streaks to unlock special characters
            </li>
            <li className="flex items-center gap-2">
              <Smile className="w-4 h-4 text-gosmile-yellow" />
              Collect total smiles to unlock animal friends
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Complete your daily goal every day
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
}
