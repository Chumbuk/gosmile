import { ArrowLeft, HelpCircle, ChevronDown } from 'lucide-react';
import { useState } from 'react';

interface FAQProps {
  onBack: () => void;
}

const faqs = [
  {
    question: 'How does GoSmile work?',
    answer: 'GoSmile uses AI-powered facial recognition to detect your smiles in real-time. Simply open the camera, smile naturally, and the app will count your smiles toward your daily goal of 200 smiles.',
  },
  {
    question: 'Why 200 smiles a day?',
    answer: 'Research shows that smiling releases endorphins, reduces stress, and improves mood. Our goal of 200 smiles is designed to help you build a positive habit and experience the mental health benefits of frequent smiling.',
  },
  {
    question: 'Is my camera data stored?',
    answer: 'No, your camera data is processed locally on your device and never stored or sent to any server. Your privacy is our priority.',
  },
  {
    question: 'How do I unlock new avatars?',
    answer: 'Avatars are unlocked by achieving milestones: maintaining daily streaks, collecting total smiles, or completing daily goals. Check the avatar selection screen to see the requirements for each character.',
  },
  {
    question: 'What happens if I miss a day?',
    answer: 'If you miss completing your daily goal, your streak will reset to 0. However, your total smile count and unlocked avatars are preserved. You can always start a new streak!',
  },
  {
    question: 'When does my daily progress reset?',
    answer: 'Your daily progress resets at midnight local time. Make sure to complete your 200 smiles before then to maintain your streak!',
  },
  {
    question: 'The camera isn\'t detecting my smile. What should I do?',
    answer: 'Ensure you have good lighting, position your face clearly in the camera circle, and smile naturally with your mouth slightly open. Avoid wearing masks or sunglasses that cover your mouth.',
  },
  {
    question: 'Can I use GoSmile offline?',
    answer: 'Yes! Once the app is loaded, you can use the smile counter and track your progress without an internet connection. Your data is stored locally on your device.',
  },
];

export function FAQ({ onBack }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4">
        <button
          onClick={onBack}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <span className="text-lg font-bold text-white">FAQ</span>
        <div className="w-9" /> {/* Spacer for alignment */}
      </header>

      {/* Main Content */}
      <main className="flex-1 px-6 py-4">
        {/* Title */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full bg-gosmile-yellow/20 flex items-center justify-center mx-auto mb-4">
            <HelpCircle className="w-8 h-8 text-gosmile-yellow" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Frequently Asked Questions</h1>
          <p className="text-white/60">Everything you need to know about GoSmile</p>
        </div>

        {/* FAQ List */}
        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-4 text-left"
              >
                <span className="text-white font-medium pr-4">{faq.question}</span>
                <ChevronDown
                  className={`w-5 h-5 text-white/50 flex-shrink-0 transition-transform duration-200 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openIndex === index && (
                <div className="px-4 pb-4">
                  <p className="text-white/70 text-sm leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact Support */}
        <div className="mt-6 p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20">
          <h3 className="text-white font-semibold mb-2">Still have questions?</h3>
          <p className="text-white/60 text-sm mb-3">
            If you couldn&apos;t find the answer you&apos;re looking for, feel free to reach out to our support team.
          </p>
          <button className="text-gosmile-yellow text-sm font-medium hover:underline">
            Contact Support →
          </button>
        </div>
      </main>
    </div>
  );
}
