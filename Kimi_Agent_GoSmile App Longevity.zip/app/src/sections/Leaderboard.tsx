import { ArrowLeft, Trophy, Medal, Flame, Crown } from 'lucide-react';
import type { UserProgress } from '@/types';

interface LeaderboardProps {
  onBack: () => void;
  userProgress: UserProgress;
}

// Mock leaderboard data
const leaderboardData = [
  { rank: 1, name: 'SmileMaster', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=1', streak: 45, total: 15420 },
  { rank: 2, name: 'HappyFace', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=2', streak: 42, total: 12850 },
  { rank: 3, name: 'JoyfulJane', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=3', streak: 38, total: 11200 },
  { rank: 4, name: 'BeamingBob', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=4', streak: 35, total: 9870 },
  { rank: 5, name: 'GrinningGuru', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=5', streak: 32, total: 8650 },
  { rank: 6, name: 'CheerfulCat', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=6', streak: 28, total: 7230 },
  { rank: 7, name: 'RadiantRay', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=7', streak: 25, total: 6540 },
  { rank: 8, name: 'SunnySam', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=8', streak: 22, total: 5890 },
  { rank: 9, name: 'BlissfulBen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=9', streak: 19, total: 4320 },
  { rank: 10, name: 'MerryMax', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=10', streak: 15, total: 3650 },
];

export function Leaderboard({ onBack, userProgress }: LeaderboardProps) {
  // Calculate user's rank based on total smiles
  const userTotal = userProgress.totalSmiles;
  const userRank = leaderboardData.filter(u => u.total > userTotal).length + 1;

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4">
        <button
          onClick={onBack}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <span className="text-lg font-bold text-white">Leaderboard</span>
        <div className="w-9" /> {/* Spacer for alignment */}
      </header>

      {/* Main Content */}
      <main className="flex-1 px-6 py-4">
        {/* Title */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Top Smilers</h1>
          <p className="text-white/60">See how you rank against other smilers</p>
        </div>

        {/* Top 3 Podium */}
        <div className="flex justify-center items-end gap-4 mb-8">
          {/* 2nd Place */}
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-gray-300 to-gray-400 p-0.5 mb-2">
              <img
                src={leaderboardData[1].avatar}
                alt={leaderboardData[1].name}
                className="w-full h-full rounded-full object-cover bg-gosmile-bg"
              />
            </div>
            <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center mb-1">
              <span className="text-gray-800 font-bold text-sm">2</span>
            </div>
            <p className="text-white text-sm font-medium">{leaderboardData[1].name}</p>
            <p className="text-white/50 text-xs">{leaderboardData[1].total.toLocaleString()}</p>
          </div>

          {/* 1st Place */}
          <div className="flex flex-col items-center -mt-4">
            <Crown className="w-6 h-6 text-yellow-400 mb-1" />
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 p-1 mb-2">
              <img
                src={leaderboardData[0].avatar}
                alt={leaderboardData[0].name}
                className="w-full h-full rounded-full object-cover bg-gosmile-bg"
              />
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center mb-1">
              <span className="text-white font-bold">1</span>
            </div>
            <p className="text-white font-medium">{leaderboardData[0].name}</p>
            <p className="text-gosmile-yellow text-sm">{leaderboardData[0].total.toLocaleString()}</p>
          </div>

          {/* 3rd Place */}
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-600 to-amber-700 p-0.5 mb-2">
              <img
                src={leaderboardData[2].avatar}
                alt={leaderboardData[2].name}
                className="w-full h-full rounded-full object-cover bg-gosmile-bg"
              />
            </div>
            <div className="w-8 h-8 rounded-full bg-amber-700 flex items-center justify-center mb-1">
              <span className="text-white font-bold text-sm">3</span>
            </div>
            <p className="text-white text-sm font-medium">{leaderboardData[2].name}</p>
            <p className="text-white/50 text-xs">{leaderboardData[2].total.toLocaleString()}</p>
          </div>
        </div>

        {/* Leaderboard List */}
        <div className="space-y-2">
          <h3 className="text-white/60 text-sm font-medium mb-3">All Rankings</h3>
          
          {leaderboardData.slice(3).map((user) => (
            <div
              key={user.rank}
              className="flex items-center gap-4 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
            >
              <span className="w-8 text-center text-white/50 font-medium">{user.rank}</span>
              <img
                src={user.avatar}
                alt={user.name}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div className="flex-1">
                <p className="text-white font-medium">{user.name}</p>
                <div className="flex items-center gap-2 text-xs text-white/50">
                  <Flame className="w-3 h-3 text-orange-500" />
                  <span>{user.streak} day streak</span>
                </div>
              </div>
              <span className="text-gosmile-yellow font-bold">{user.total.toLocaleString()}</span>
            </div>
          ))}

          {/* User's Position */}
          <div className="mt-4 p-4 rounded-xl bg-gradient-to-r from-gosmile-yellow/20 to-orange-500/20 border border-gosmile-yellow/30">
            <h3 className="text-gosmile-yellow text-sm font-medium mb-3">Your Position</h3>
            <div className="flex items-center gap-4">
              <span className="w-8 text-center text-white font-bold">{userRank}</span>
              <div className="w-10 h-10 rounded-full bg-gosmile-yellow flex items-center justify-center">
                <span className="text-black font-bold">You</span>
              </div>
              <div className="flex-1">
                <p className="text-white font-medium">Your Progress</p>
                <div className="flex items-center gap-2 text-xs text-white/50">
                  <Flame className="w-3 h-3 text-orange-500" />
                  <span>{userProgress.streak} day streak</span>
                </div>
              </div>
              <span className="text-gosmile-yellow font-bold">{userTotal.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Stats Summary */}
        <div className="mt-6 grid grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-white/5 text-center">
            <Medal className="w-6 h-6 text-gosmile-yellow mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">#{userRank}</p>
            <p className="text-white/50 text-sm">Your Rank</p>
          </div>
          <div className="p-4 rounded-xl bg-white/5 text-center">
            <Trophy className="w-6 h-6 text-gosmile-yellow mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">
              {Math.max(0, leaderboardData[0].total - userTotal).toLocaleString()}
            </p>
            <p className="text-white/50 text-sm">To 1st Place</p>
          </div>
        </div>
      </main>
    </div>
  );
}
