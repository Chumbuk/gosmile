import { User, Trophy, Flame, Smile } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { UserProgress, Avatar } from '@/types';

interface DashboardProps {
  progress: UserProgress;
  selectedAvatar: Avatar;
  dailyProgressPercentage: number;
  isDailyGoalCompleted: boolean;
  onStartCamera: () => void;
  onOpenAvatars: () => void;
}

export function Dashboard({
  progress,
  selectedAvatar,
  dailyProgressPercentage,
  isDailyGoalCompleted,
  onStartCamera,
  onOpenAvatars,
}: DashboardProps) {
  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-black tracking-tight">
            <span className="text-white">go</span>
            <span className="text-gosmile-yellow">smile</span>
            <span className="text-gosmile-yellow">!</span>
          </span>
        </div>
        <button className="p-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors">
          <User className="w-5 h-5 text-white" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center px-6 py-4 gap-6">
        {/* Streak Badge */}
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30">
          <Flame className="w-5 h-5 text-orange-500" />
          <span className="text-white font-semibold">{progress.streak} Day Streak</span>
        </div>

        {/* Active Avatar */}
        <div className="relative">
          <div 
            className={`w-48 h-48 rounded-full overflow-hidden border-4 transition-all duration-300 ${
              isDailyGoalCompleted 
                ? 'border-gosmile-green shadow-glow-green' 
                : 'border-gosmile-yellow shadow-glow-yellow'
            }`}
          >
            <img
              src={selectedAvatar.image}
              alt={selectedAvatar.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                // Fallback to placeholder if image fails to load
                (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedAvatar.id}`;
              }}
            />
          </div>
          
          {/* Avatar Selection Button */}
          <button
            onClick={onOpenAvatars}
            className="absolute -bottom-2 -right-2 w-12 h-12 rounded-full bg-gosmile-yellow hover:bg-gosmile-yellow-light text-black flex items-center justify-center shadow-lg transition-transform hover:scale-110"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>

          {/* Completion Badge */}
          {isDailyGoalCompleted && (
            <div className="absolute -top-2 -right-2 w-14 h-14 rounded-full bg-gosmile-green flex items-center justify-center shadow-glow-green animate-bounce">
              <Trophy className="w-7 h-7 text-white" />
            </div>
          )}
        </div>

        {/* Avatar Name */}
        <p className="text-white/80 font-medium">{selectedAvatar.name}</p>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4 w-full max-w-sm">
          {/* Goal Card */}
          <div className="stat-card bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/30">
            <span className="text-xs text-blue-400 uppercase tracking-wider font-semibold">Goal</span>
            <span className="text-3xl font-black text-blue-400">{progress.dailyGoal}</span>
            <span className="text-xs text-blue-400/70">smiles</span>
          </div>

          {/* Done Card */}
          <div className="stat-card bg-gradient-to-br from-purple-500/20 to-purple-600/10 border border-purple-500/30">
            <span className="text-xs text-purple-400 uppercase tracking-wider font-semibold">Done</span>
            <span className="text-3xl font-black text-purple-400">{progress.dailyDone}</span>
            <span className="text-xs text-purple-400/70">smiles</span>
          </div>

          {/* Ready Card */}
          <div className="stat-card bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30">
            <span className="text-xs text-green-400 uppercase tracking-wider font-semibold">Ready</span>
            <span className="text-3xl font-black text-green-400">{Math.round(dailyProgressPercentage)}%</span>
            <span className="text-xs text-green-400/70">complete</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full max-w-sm">
          <div className="h-3 bg-white/10 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isDailyGoalCompleted 
                  ? 'bg-gradient-to-r from-green-400 to-green-500' 
                  : 'bg-gradient-to-r from-yellow-400 to-yellow-500'
              }`}
              style={{ width: `${dailyProgressPercentage}%` }}
            />
          </div>
          <p className="text-center text-white/60 text-sm mt-2">
            {isDailyGoalCompleted 
              ? '🎉 Daily goal completed! Great job!' 
              : `${progress.dailyGoal - progress.dailyDone} more smiles to reach your goal`}
          </p>
        </div>

        {/* Total Smiles */}
        <div className="flex items-center gap-3 px-6 py-3 rounded-2xl bg-white/5 border border-white/10">
          <div className="w-10 h-10 rounded-full bg-gosmile-yellow/20 flex items-center justify-center">
            <Smile className="w-5 h-5 text-gosmile-yellow" />
          </div>
          <div>
            <p className="text-white/60 text-xs">Total Smiles</p>
            <p className="text-white font-bold text-lg">{progress.totalSmiles.toLocaleString()}</p>
          </div>
        </div>

        {/* GO Button */}
        <Button
          onClick={onStartCamera}
          className={`w-32 h-32 rounded-full text-4xl font-black transition-all duration-300 ${
            isDailyGoalCompleted
              ? 'bg-gosmile-green hover:bg-green-400 shadow-glow-green'
              : 'bg-gosmile-yellow hover:bg-gosmile-yellow-light shadow-glow-yellow animate-pulse-glow'
          }`}
        >
          {isDailyGoalCompleted ? '✓' : 'GO!'}
        </Button>

        <p className="text-white/50 text-sm text-center">
          {isDailyGoalCompleted 
            ? 'You\'ve completed today\'s challenge!' 
            : 'Tap to start smiling'}
        </p>
      </main>
    </div>
  );
}
