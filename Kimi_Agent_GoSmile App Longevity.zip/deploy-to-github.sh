#!/bin/bash

# GoSmile GitHub Pages Deployment Script
# Usage: ./deploy-to-github.sh YOUR_GITHUB_USERNAME REPO_NAME

set -e

USERNAME=$1
REPO_NAME=$2

if [ -z "$USERNAME" ] || [ -z "$REPO_NAME" ]; then
    echo "Usage: ./deploy-to-github.sh YOUR_GITHUB_USERNAME REPO_NAME"
    echo "Example: ./deploy-to-github.sh johndoe gosmile"
    exit 1
fi

echo "🚀 Deploying GoSmile to GitHub Pages..."
echo "Username: $USERNAME"
echo "Repository: $REPO_NAME"

# Update vite.config.ts with the correct base
sed -i "s|base: './'|base: '/$REPO_NAME/'|" vite.config.ts
echo "✅ Updated vite.config.ts with base: '/$REPO_NAME/'"

# Build the project
echo "📦 Building project..."
npm run build

# Create a temporary directory for deployment
DEPLOY_DIR=$(mktemp -d)
cp -r dist/* "$DEPLOY_DIR/"

# Initialize git in deploy directory
cd "$DEPLOY_DIR"
git init
git checkout -b gh-pages

# Copy all files to root
git add .
git commit -m "Deploy GoSmile to GitHub Pages"

# Add remote and push
git remote add origin "https://github.com/$USERNAME/$REPO_NAME.git"
echo "🔄 Pushing to GitHub..."
git push -f origin gh-pages

# Cleanup
cd -
rm -rf "$DEPLOY_DIR"

echo ""
echo "✅ Deployment complete!"
echo ""
echo "🌐 Your site will be available at:"
echo "   https://$USERNAME.github.io/$REPO_NAME/"
echo ""
echo "⏳ Note: It may take 1-5 minutes for the site to go live."
echo ""
echo "📋 Next steps:"
echo "   1. Go to https://github.com/$USERNAME/$REPO_NAME/settings/pages"
echo "   2. Ensure 'Source' is set to 'Deploy from a branch'"
echo "   3. Select 'gh-pages' branch and '/ (root)' folder"
echo "   4. Click 'Save'"
