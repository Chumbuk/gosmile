# Deploy GoSmile to GitHub Pages

## Step 1: Create a GitHub Repository

1. Go to [GitHub](https://github.com) and sign in
2. Click the **+** button → **New repository**
3. Name it `gosmile` (or any name you prefer)
4. Make it **Public**
5. Click **Create repository**

## Step 2: Prepare the Project for GitHub Pages

The project is already built in the `/mnt/okcomputer/output/app` folder. You need to:

### Option A: Deploy from `main` branch (Root)

1. Copy all files from `/mnt/okcomputer/output/app` to your local machine
2. Initialize git and push to GitHub:

```bash
# Navigate to the project folder
cd /path/to/gosmile

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit"

# Add remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/gosmile.git

# Push to GitHub
git push -u origin main
```

3. Enable GitHub Pages:
   - Go to your repository on GitHub
   - Click **Settings** → **Pages** (in the left sidebar)
   - Under "Source", select **Deploy from a branch**
   - Select **main** branch and **/(root)** folder
   - Click **Save**

### Option B: Deploy from `gh-pages` branch (Recommended)

This keeps your source code separate from the built files:

```bash
# Navigate to the project folder
cd /path/to/gosmile

# Create a new branch for GitHub Pages
git checkout -b gh-pages

# Remove source files, keep only dist content
git rm -rf .
git checkout main -- dist/
mv dist/* .
rmdir dist

# Commit and push
git add .
git commit -m "Deploy to GitHub Pages"
git push origin gh-pages

# Go back to main branch
git checkout main
```

Then in GitHub Settings → Pages:
- Select **Deploy from a branch**
- Select **gh-pages** branch
- Click **Save**

## Step 3: Configure Vite for GitHub Pages (Important!)

You need to update the Vite config to handle the base URL. Edit `vite.config.ts`:

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  base: '/gosmile/', // Replace 'gosmile' with your repository name
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
```

Then rebuild:
```bash
npm run build
```

## Step 4: Update index.html for GitHub Pages

Make sure your `index.html` has the correct paths. The built files should work, but double-check that asset paths are relative.

## Step 5: Wait for Deployment

After pushing and configuring:
1. Go to **Settings** → **Pages** in your repository
2. You'll see a message like "Your site is ready to be published at `https://yourusername.github.io/gosmile/`"
3. Wait 1-5 minutes for the site to go live

## Your Site Will Be At:

```
https://YOUR_USERNAME.github.io/gosmile/
```

## Updating Your Site

When you make changes:

```bash
# Make your changes
# Rebuild
npm run build

# If using gh-pages branch:
git checkout gh-pages
git rm -rf .
cp -r dist/* .
git add .
git commit -m "Update site"
git push origin gh-pages
```

## Troubleshooting

### 404 Errors
- Make sure `base` in `vite.config.ts` matches your repository name
- Check that GitHub Pages is enabled in Settings

### Assets Not Loading
- Ensure all paths in your code use relative paths (`./` or no leading slash)
- The `base` config should handle this automatically

### Camera Not Working
- GitHub Pages requires HTTPS (which it provides)
- Camera permissions must be allowed by the user
- Some browsers block camera on insecure contexts (GitHub Pages is secure)

## Alternative: Use GitHub Actions (Auto-Deploy)

Create `.github/workflows/deploy.yml` in your repository:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Build
        run: npm run build
      
      - name: Setup Pages
        uses: actions/configure-pages@v4
      
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: './dist'
      
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

Then in Settings → Pages:
- Select **GitHub Actions** as the source

This will automatically deploy whenever you push to main!

---

## Quick Summary

1. Create GitHub repo
2. Clone/push the project
3. Update `vite.config.ts` with `base: '/repo-name/'`
4. Run `npm run build`
5. Push the `dist` folder to `gh-pages` branch
6. Enable GitHub Pages in Settings
7. Done! 🎉
