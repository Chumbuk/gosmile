# Quick Deploy to GitHub Pages

## Prerequisites
- GitHub account
- Git installed on your computer
- Node.js 18+ installed

## Method 1: Using the Deploy Script (Easiest)

1. **Create a new repository on GitHub**
   - Go to https://github.com/new
   - Name it `gosmile` (or any name)
   - Make it Public
   - Don't initialize with README

2. **Download the project files**
   - Copy the `/mnt/okcomputer/output/app` folder to your computer

3. **Run the deploy script**
   ```bash
   cd /path/to/app
   ./deploy-to-github.sh YOUR_GITHUB_USERNAME gosmile
   ```

4. **Enable GitHub Pages**
   - Go to `https://github.com/YOUR_USERNAME/gosmile/settings/pages`
   - Select "Deploy from a branch"
   - Select "gh-pages" branch
   - Click Save

5. **Wait 1-5 minutes** and visit:
   ```
   https://YOUR_USERNAME.github.io/gosmile/
   ```

---

## Method 2: Manual Deployment

### Step 1: Create Repository
Create a new public repository on GitHub named `gosmile`.

### Step 2: Update Config
Edit `vite.config.ts`:
```typescript
export default defineConfig({
  base: '/gosmile/',  // Add your repo name here
  // ... rest of config
})
```

### Step 3: Build
```bash
npm install
npm run build
```

### Step 4: Deploy
```bash
# Create gh-pages branch
cd dist
git init
git checkout -b gh-pages
git add .
git commit -m "Deploy"
git remote add origin https://github.com/YOUR_USERNAME/gosmile.git
git push -f origin gh-pages
```

### Step 5: Enable Pages
Go to Settings → Pages → Select "gh-pages" branch → Save

---

## Method 3: Drag & Drop (No Git Required!)

1. **Build the project**
   ```bash
   cd app
   npm install
   npm run build
   ```

2. **Zip the dist folder**
   ```bash
   cd dist
   zip -r ../gosmile.zip .
   ```

3. **Upload to GitHub**
   - Go to your repository on GitHub
   - Click "Upload files"
   - Drag and drop all files from the `dist` folder
   - Commit to a new branch called `gh-pages`

4. **Enable Pages** in Settings

---

## Your Site URL

After deployment, your site will be at:
```
https://YOUR_USERNAME.github.io/gosmile/
```

## Updating Your Site

To update after making changes:

```bash
# Rebuild
npm run build

# Redeploy
cd dist
git add .
git commit -m "Update"
git push origin gh-pages
```

Or use the deploy script again!

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| 404 error | Check that `base` in vite.config.ts matches your repo name |
| Blank page | Open browser console (F12) and check for errors |
| Assets not loading | Make sure paths are relative or match base URL |
| Camera not working | GitHub Pages uses HTTPS - camera should work. Check browser permissions. |

## Need Help?

Check the full guide: `DEPLOY_TO_GITHUB.md`
